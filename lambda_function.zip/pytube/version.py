__version__ = "15.0.0"

if __name__ == "__main__":
    print(__version__)
