def lambda_function():
    return 200
